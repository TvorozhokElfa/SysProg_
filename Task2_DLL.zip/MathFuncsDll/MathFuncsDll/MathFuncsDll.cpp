﻿// dllmain.cpp : Определяет точку входа для приложения DLL.
#include "framework.h"
#include <math.h>

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

// MathFuncsDll.cpp : Defines the exported functions for the DLL application.
#include "MathFuncsDll.h"
#include <math.h>
#include <stdexcept>
#define _USE_MATH_DEFINES
#define M_PI           3.14159265358979323846
using namespace std;
namespace MathFuncs
{
    double MyMathFuncs::calculate(double x, double y)
    {
        double result = log
        (
            (y - sqrt(abs(x))) * 
            (
                x - (y / 
                    (
                        x + ((x * x) / 4)
                    ))
            )
        );
        return result;
    };

}
