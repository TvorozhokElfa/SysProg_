﻿#define WIN32_LEAN_AND_MEAN
#define _CRT_SECURE_NO_WARNINGS
// MyExecRefsDll.cpp
// compile with: /EHsc /link MathFuncsDll.lib
#include <iostream>
#include "MathFuncsDll.h"

using namespace std;
int main()
{
	double a = 5;
	try
	{
		double x, y;

		cout << "x = "; cin >> x;
		cout << "y = "; cin >> y;

		cout << "result = " << MathFuncs::MyMathFuncs::calculate(x, y);
	}
	catch (const invalid_argument& e)
	{
		cout << "Caught exception: " << e.what() << endl;
	}
	return 0;
}
